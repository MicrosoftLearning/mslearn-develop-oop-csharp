using System;
using System.Collections.Generic;
using System.Linq;

namespace BankApp;

// TASK 2: Define Enum, Struct, and Record types

// TASK 2: Step 1 - Define the BankAccountType enum with Checking, Savings, and Business values


// TASK 2: Step 2 - Define an extension method to provide descriptions for each BankAccountType value


// TASK 2: Step 3 - Define the BankAccountNumber struct


// TASK 2: Step 4 - Define the AccountHolderDetails record


// TASK 2: Step 5 - Define the Transaction record



public class BankAccount
{
    // TASK 3: Implement the BankAccount class
    // TASK 3: Step 1 - Add properties for BankAccountNumber, BankAccountType, Balance, AccountHolderDetails, and a Transactions list.



    // TASK 3: Step 2 - Add a constructor to initialize the properties.
 

    // TASK 3: Step 3 - Add a method for deposits/withdrawals that updates the balance and records the transaction.


    // TASK 3: Step 4 - Add a method to display account information.


    // TASK 3: Step 5 - Add a method to display transactions.

}
