// TASK 2: Create an interface IDataAccess for data access operations.
